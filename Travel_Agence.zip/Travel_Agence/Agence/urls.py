
from django import views
from django.urls import include, path
from .views import *

urlpatterns = [
   
    path('',home,name="home"),
    path('login',login,name="login"),
    path('register',register,name="register")
]
